// =====================================================================
// API Checker — плагин для Оникса
//
// Проверяет работу методов API третьей очереди:
//  - oniks.notes.getAllWithBody()
//  - oniks.notes.getRecent(limit)
//  - oniks.notes.getPinned()
//  - oniks.ui.openNote(id)
//
// ВАЖНО: Rhino 1.7.14 — ES5. Без lookbehind, стрелок, let/const.
// ВАЖНО: try/catch НЕ работает (крашится на newCatchScope).
// ВАЖНО: .call() на методах oniks.* НЕ работает — вызывай напрямую.
// =====================================================================


// =====================================================================
// ЧАСТЬ 1. УТИЛИТЫ
// =====================================================================

function makeResult(name, ok, details) {
    return { name: name, ok: ok, details: details || "" };
}

function isArray(value) {
    return value !== null &&
        value !== undefined &&
        typeof value.length === "number";
}

function isString(value) {
    return typeof value === "string";
}

function formatResult(result) {
    var mark = result.ok ? "[OK]" : "[FAIL]";
    var line = mark + "  " + result.name;
    if (result.details) {
        line += "\n      " + result.details;
    }
    return line;
}

function formatResults(results) {
    var lines = [];
    var passed = 0;
    var failed = 0;
    for (var i = 0; i < results.length; i++) {
        lines.push(formatResult(results[i]));
        if (results[i].ok) passed++;
        else failed++;
    }
    lines.push("");
    lines.push("Пройдено: " + passed + " / " + results.length);
    if (failed > 0) {
        lines.push("Провалено: " + failed);
    }
    return lines.join("\n");
}


// =====================================================================
// ЧАСТЬ 2. ТЕСТЫ
// =====================================================================

function testGetAllWithBody() {
    var results = [];

    // 1. Namespace.
    if (typeof oniks === "undefined" || oniks === null) {
        results.push(makeResult("oniks — объект существует", false, ""));
        return results;
    }
    results.push(makeResult("oniks — объект существует", true, ""));

    if (typeof oniks.notes === "undefined" || oniks.notes === null) {
        results.push(makeResult("oniks.notes — namespace существует", false, ""));
        return results;
    }
    results.push(makeResult("oniks.notes — namespace существует", true, ""));

    // 2. Метод существует.
    if (typeof oniks.notes.getAllWithBody !== "function") {
        results.push(makeResult("getAllWithBody — метод существует", false, "не функция"));
        return results;
    }
    results.push(makeResult("getAllWithBody — метод существует", true, ""));

    // 3. Прямой вызов.
    var all = oniks.notes.getAllWithBody();

    if (!isArray(all)) {
        results.push(makeResult("getAllWithBody() — возвращает массив", false, "тип: " + typeof all));
        return results;
    }
    results.push(makeResult("getAllWithBody() — возвращает массив", true, "длина: " + all.length));

    if (all.length === 0) {
        results.push(makeResult("getAllWithBody() — структура", true, "пропущено (пусто)"));
        return results;
    }

    var first = all[0];

    var hasBody = isString(first.body);
    results.push(makeResult(
        "getAllWithBody() — поле body (string)",
        hasBody,
        hasBody ? "длина: " + first.body.length : "тип: " + typeof first.body
    ));

    var hasCollectionId = ("collectionId" in first);
    results.push(makeResult(
        "getAllWithBody() — поле collectionId",
        hasCollectionId,
        hasCollectionId ? "значение: " + (first.collectionId || "(null)") : "отсутствует"
    ));

    var hasId = isString(first.id);
    results.push(makeResult(
        "getAllWithBody() — поле id (string)",
        hasId,
        hasId ? "id: " + first.id.substring(0, 8) + "..." : "тип: " + typeof first.id
    ));

    var hasTitle = isString(first.title);
    results.push(makeResult(
        "getAllWithBody() — поле title (string)",
        hasTitle,
        hasTitle ? "title: " + (first.title || "(пусто)") : "тип: " + typeof first.title
    ));

    var hasTags = isArray(first.tags);
    results.push(makeResult(
        "getAllWithBody() — поле tags (array)",
        hasTags,
        hasTags ? "тегов: " + first.tags.length : "тип: " + typeof first.tags
    ));

    // 4. Сверка с getAll.
    var meta = oniks.notes.getAll();
    results.push(makeResult(
        "getAllWithBody() и getAll() — одинаковое число",
        meta.length === all.length,
        "getAll: " + meta.length + ", getAllWithBody: " + all.length
    ));

    return results;
}

function testGetRecent() {
    var results = [];

    if (typeof oniks === "undefined" || typeof oniks.notes === "undefined") {
        results.push(makeResult("oniks.notes — namespace", false, ""));
        return results;
    }

    if (typeof oniks.notes.getRecent !== "function") {
        results.push(makeResult("getRecent — метод существует", false, "не функция"));
        return results;
    }
    results.push(makeResult("getRecent — метод существует", true, ""));

    // Прямой вызов.
    var recent = oniks.notes.getRecent(3);

    if (!isArray(recent)) {
        results.push(makeResult("getRecent(3) — массив", false, "тип: " + typeof recent));
        return results;
    }
    results.push(makeResult("getRecent(3) — массив", true, "длина: " + recent.length));

    results.push(makeResult(
        "getRecent(3) — длина <= 3",
        recent.length <= 3,
        "длина: " + recent.length
    ));

    if (recent.length >= 2) {
        var sorted = true;
        for (var i = 1; i < recent.length; i++) {
            if (recent[i].updated > recent[i - 1].updated) {
                sorted = false;
                break;
            }
        }
        results.push(makeResult(
            "getRecent(3) — сортировка по updated",
            sorted,
            sorted ? "" : "нарушена"
        ));
    } else {
        results.push(makeResult("getRecent(3) — сортировка", true, "пропущено"));
    }

    var one = oniks.notes.getRecent(1);
    var all = oniks.notes.getAll();
    var expected = all.length > 0 ? 1 : 0;
    results.push(makeResult(
        "getRecent(1) — ровно 1 (если есть)",
        one.length === expected,
        "получено: " + one.length + ", ожидалось: " + expected
    ));

    var big = oniks.notes.getRecent(1000);
    results.push(makeResult(
        "getRecent(1000) — <= всего",
        big.length <= all.length,
        "получено: " + big.length + ", всего: " + all.length
    ));

    return results;
}

function testGetPinned() {
    var results = [];

    if (typeof oniks === "undefined" || typeof oniks.notes === "undefined") {
        results.push(makeResult("oniks.notes — namespace", false, ""));
        return results;
    }

    if (typeof oniks.notes.getPinned !== "function") {
        results.push(makeResult("getPinned — метод существует", false, "не функция"));
        return results;
    }
    results.push(makeResult("getPinned — метод существует", true, ""));

    var pinned = oniks.notes.getPinned();

    if (!isArray(pinned)) {
        results.push(makeResult("getPinned() — массив", false, "тип: " + typeof pinned));
        return results;
    }
    results.push(makeResult("getPinned() — массив", true, "закреплённых: " + pinned.length));

    var allPinned = true;
    for (var i = 0; i < pinned.length; i++) {
        if (pinned[i].pinned !== true) {
            allPinned = false;
            break;
        }
    }
    results.push(makeResult(
        "getPinned() — все pinned === true",
        allPinned,
        allPinned ? "" : "найден без pinned"
    ));

    var all = oniks.notes.getAll();
    var expected = 0;
    for (var j = 0; j < all.length; j++) {
        if (all[j].pinned === true) expected++;
    }
    results.push(makeResult(
        "getPinned() — совпадает с фильтром getAll",
        pinned.length === expected,
        "getPinned: " + pinned.length + ", фильтр: " + expected
    ));

    return results;
}

function testOpenNote() {
    var results = [];

    if (typeof oniks === "undefined" || oniks === null) {
        results.push(makeResult("oniks — объект", false, ""));
        return results;
    }
    results.push(makeResult("oniks — объект", true, ""));

    if (typeof oniks.ui === "undefined" || oniks.ui === null) {
        results.push(makeResult("oniks.ui — namespace", false, "не найден"));
        return results;
    }
    results.push(makeResult("oniks.ui — namespace", true, ""));

    if (typeof oniks.ui.openNote !== "function") {
        results.push(makeResult("openNote — метод существует", false, "не функция"));
        return results;
    }
    results.push(makeResult("openNote — метод существует", true, ""));

    // Пустой id → false.
    var emptyResult = oniks.ui.openNote("");
    results.push(makeResult(
        "openNote(\"\") — false",
        emptyResult === false,
        "получено: " + emptyResult
    ));

    // Несуществующий id — не падает.
    var fakeResult = oniks.ui.openNote("00000000-0000-0000-0000-000000000000");
    results.push(makeResult(
        "openNote(несуществующий) — не падает",
        true,
        "вернул: " + fakeResult
    ));

    results.push(makeResult(
        "openNote(реальная) — отдельная команда",
        true,
        "используйте «API Checker: открыть заметку»"
    ));

    return results;
}


// =====================================================================
// ЧАСТЬ 3. КОМАНДЫ
// =====================================================================

oniks.commands.register({
    id: "check-all",
    title: "API Checker: проверить всё",
    handler: function() {
        oniks.log.info("API Checker: запуск полной проверки");

        var allResults = [];
        allResults = allResults.concat(testGetAllWithBody());
        allResults = allResults.concat(testGetRecent());
        allResults = allResults.concat(testGetPinned());
        allResults = allResults.concat(testOpenNote());

        var report = formatResults(allResults);
        oniks.dialog.alert(report, "API Checker: результаты");

        oniks.log.info("API Checker: проверка завершена");
    }
});

oniks.commands.register({
    id: "check-getAllWithBody",
    title: "API Checker: getAllWithBody",
    handler: function() {
        var results = testGetAllWithBody();
        oniks.dialog.alert(formatResults(results), "Тест: getAllWithBody");
    }
});

oniks.commands.register({
    id: "check-getRecent",
    title: "API Checker: getRecent",
    handler: function() {
        var results = testGetRecent();
        oniks.dialog.alert(formatResults(results), "Тест: getRecent");
    }
});

oniks.commands.register({
    id: "check-getPinned",
    title: "API Checker: getPinned",
    handler: function() {
        var results = testGetPinned();
        oniks.dialog.alert(formatResults(results), "Тест: getPinned");
    }
});

oniks.commands.register({
    id: "check-openNote",
    title: "API Checker: открыть заметку",
    handler: function() {
        var all = oniks.notes.getAll();
        if (all.length === 0) {
            oniks.dialog.alert("Заметок нет.", "Тест: openNote");
            return;
        }

        var index = Math.floor(Math.random() * all.length);
        var note = all[index];

        oniks.dialog.alert(
            "Открою случайную заметку:\n\n" +
            "«" + note.title + "»\n" +
            "id: " + note.id.substring(0, 8) + "...\n\n" +
            "Если откроется просмотрщик — тест пройден.",
            "Тест: openNote"
        );

        var ok = oniks.ui.openNote(note.id);
        oniks.log.info("API Checker: openNote вернул " + ok);
    }
});

oniks.commands.register({
    id: "check-info",
    title: "API Checker: справка",
    handler: function() {
        var message =
            "API Checker проверяет методы третьей очереди API:\n\n" +
            "• getAllWithBody()\n" +
            "• getRecent(limit)\n" +
            "• getPinned()\n" +
            "• ui.openNote(id)\n\n" +
            "Команда «проверить всё» прогоняет все тесты.\n\n" +
            "Разрешения: commands, read_notes, ui_dialog.";

        oniks.dialog.alert(message, "API Checker: справка");
    }
});


// =====================================================================
// INIT
// =====================================================================

oniks.log.info("API Checker loaded, commands: 6");
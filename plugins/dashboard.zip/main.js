// =====================================================================
// Сводка (Dashboard) — плагин для Оникса
//
// Показывает сводку по всей базе заметок:
//  - общая статистика
//  - топ-10 тегов
//  - хабы (заметки с максимумом входящих ссылок)
//  - изолированные заметки (0 связей и 0 тегов)
//  - красные ссылки (упомянуты в [[...]], но заметок нет)
//  - дубликаты заголовков
//  - заметки без коллекции
//  - пустые заметки
//
// Полный отчёт идёт конвейером: пользователь может прервать
// на любой секции, нажав «Нет».
//
// ВАЖНО: Rhino 1.7.14 — ES5. Без lookbehind, стрелок, let/const.
// =====================================================================


// =====================================================================
// ЧАСТЬ 1. КОНФИГ И УТИЛИТЫ
// =====================================================================

var TOP_N = 10;
var MAX_TITLE_LENGTH = 40;

function trim(s) {
    return s.replace(/^\s+|\s+$/g, "");
}

/**
 * Обрезает строку до MAX_TITLE_LENGTH символов, добавляя «…».
 */
function ellipsize(s) {
    if (!s) return "";
    if (s.length <= MAX_TITLE_LENGTH) return s;
    return s.substring(0, MAX_TITLE_LENGTH - 1) + "…";
}

/**
 * Экранирует спецсимволы для regex.
 */
function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Форматирует число элементов с «и ещё N».
 */
function listOrTruncated(items, max) {
    var result = [];
    var limit = Math.min(items.length, max);
    for (var i = 0; i < limit; i++) {
        result.push(items[i]);
    }
    if (items.length > max) {
        result.push("... и ещё " + (items.length - max));
    }
    return result.join("\n");
}


// =====================================================================
// ЧАСТЬ 2. СБОР ДАННЫХ
// =====================================================================

/**
 * Один проход по всем заметкам. Собирает все данные сразу.
 *
 * Возвращает объект Data со всеми полями. Если заметок нет —
 * возвращает объект с empty=true.
 */
function collectData() {
    var data = {
        empty: false,
        totalNotes: 0,
        pinnedCount: 0,
        notes: [],              // все заметки (мета, без body)
        notesById: {},          // id -> meta
        tagsCounter: {},        // tagLower -> count
        tagDisplay: {},         // tagLower -> оригинальный регистр
        incomingLinks: {},      // titleLower -> count вхождений
        allWikiTargets: {},     // titleLower -> count (для красных ссылок)
        titleGroups: {},        // titleLower -> массив id
        titleDisplay: {},       // titleLower -> оригинальный заголовок
        withoutCollection: [],  // id заметок без collectionId
        emptyNotes: [],         // id заметок без title и body
        totalLinks: 0,
        collectionsCount: 0
    };

    var all = [];
    try {
        all = oniks.notes.getAll() || [];
    } catch (e) {
        oniks.log.error("collectData: getAll error: " + e.message);
        data.empty = true;
        return data;
    }

    if (all.length === 0) {
        data.empty = true;
        return data;
    }

    data.totalNotes = all.length;
    data.notes = all;

    // 1. Первый проход — собрать метаданные без body.
    for (var i = 0; i < all.length; i++) {
        var meta = all[i];
        data.notesById[meta.id] = meta;

        if (meta.pinned) data.pinnedCount++;

        // Теги.
        var tags = meta.tags || [];
        for (var t = 0; t < tags.length; t++) {
            var tag = trim(String(tags[t]));
            if (tag.length === 0) continue;
            var tagLower = tag.toLowerCase();
            data.tagsCounter[tagLower] = (data.tagsCounter[tagLower] || 0) + 1;
            if (!data.tagDisplay[tagLower]) {
                data.tagDisplay[tagLower] = tag;
            }
        }

        // Заголовки для дубликатов.
        var title = trim(meta.title || "");
        if (title.length > 0) {
            var titleLower = title.toLowerCase();
            if (!data.titleGroups[titleLower]) {
                data.titleGroups[titleLower] = [];
                data.titleDisplay[titleLower] = title;
            }
            data.titleGroups[titleLower].push(meta.id);
        }

        // Пустые заметки: нет title и нет preview (body не читаем здесь).
        if (title.length === 0 && (!meta.preview || meta.preview.length === 0)) {
            data.emptyNotes.push(meta.id);
        }

        // Без коллекции.
        if (!meta.collectionId || meta.collectionId.length === 0) {
            data.withoutCollection.push(meta.id);
        }
    }

    // 2. Второй проход — body для поиска ссылок.
    //    getNote(id) возвращает полную заметку с body.
    var incomingLinks = {};  // titleLower -> count
    var allWikiTargets = {};
    var totalLinks = 0;

    for (var j = 0; j < all.length; j++) {
        var noteId = all[j].id;
        var full = null;
        try {
            full = oniks.notes.getNote(noteId);
        } catch (e) {
            oniks.log.warn("collectData: getNote(" + noteId + ") error: " + e.message);
            continue;
        }
        if (!full || !full.body) continue;

        var links = [];
        try {
            links = oniks.markdown.parseWikiLinks(full.body) || [];
        } catch (e) {
            oniks.log.warn("collectData: parseWikiLinks error: " + e.message);
            continue;
        }

        for (var k = 0; k < links.length; k++) {
            var target = trim(String(links[k]));
            if (target.length === 0) continue;

            var targetLower = target.toLowerCase();
            allWikiTargets[targetLower] = (allWikiTargets[targetLower] || 0) + 1;
            totalLinks++;

            // Если такая заметка существует — считаем как входящую ссылку.
            if (data.titleGroups[targetLower]) {
                incomingLinks[targetLower] = (incomingLinks[targetLower] || 0) + 1;
            }
        }
    }

    data.incomingLinks = incomingLinks;
    data.allWikiTargets = allWikiTargets;
    data.totalLinks = totalLinks;

    // 3. Коллекции.
    try {
        var collections = oniks.collections.getAll() || [];
        data.collectionsCount = collections.length;
    } catch (e) {
        oniks.log.warn("collectData: collections.getAll error: " + e.message);
        data.collectionsCount = 0;
    }

    return data;
}

/**
 * Возвращает массив id заметок, у которых 0 входящих ссылок и 0 тегов.
 */
function findIsolated(data) {
    var result = [];
    for (var i = 0; i < data.notes.length; i++) {
        var meta = data.notes[i];
        var tags = meta.tags || [];
        if (tags.length > 0) continue;

        var title = trim(meta.title || "");
        if (title.length === 0) continue;
        var titleLower = title.toLowerCase();

        var incoming = data.incomingLinks[titleLower] || 0;
        if (incoming > 0) continue;

        // Исходящие не считаем — если заметка на кого-то ссылается,
        // она всё равно изолирована с точки зрения входящих. Но для
        // полноты проверим и исходящие.
        // (Упрощение: считаем изолированной только если 0 входящих и 0 тегов.)
        result.push(meta);
    }
    return result;
}

/**
 * Возвращает массив {title, count} — топ заголовков по числу вхождений.
 */
function findHubs(data) {
    var arr = [];
    for (var titleLower in data.incomingLinks) {
        if (!data.incomingLinks.hasOwnProperty(titleLower)) continue;
        var count = data.incomingLinks[titleLower];
        if (count <= 0) continue;
        arr.push({
            title: data.titleDisplay[titleLower] || titleLower,
            count: count
        });
    }
    arr.sort(function(a, b) { return b.count - a.count; });
    return arr;
}

/**
 * Возвращает массив {title, count} — топ тегов по частоте.
 */
function findTopTags(data) {
    var arr = [];
    for (var tagLower in data.tagsCounter) {
        if (!data.tagsCounter.hasOwnProperty(tagLower)) continue;
        arr.push({
            tag: data.tagDisplay[tagLower] || tagLower,
            count: data.tagsCounter[tagLower]
        });
    }
    arr.sort(function(a, b) { return b.count - a.count; });
    return arr;
}

/**
 * Возвращает массив {title, count} — дубликаты заголовков (>=2).
 */
function findDuplicates(data) {
    var arr = [];
    for (var titleLower in data.titleGroups) {
        if (!data.titleGroups.hasOwnProperty(titleLower)) continue;
        var ids = data.titleGroups[titleLower];
        if (ids.length < 2) continue;
        arr.push({
            title: data.titleDisplay[titleLower] || titleLower,
            count: ids.length
        });
    }
    arr.sort(function(a, b) { return b.count - a.count; });
    return arr;
}

/**
 * Возвращает массив {title, count} — красные ссылки.
 * То есть цели [[...]], для которых нет заметки.
 */
function findRedLinks(data) {
    var arr = [];
    for (var targetLower in data.allWikiTargets) {
        if (!data.allWikiTargets.hasOwnProperty(targetLower)) continue;
        if (data.titleGroups[targetLower]) continue;  // заметка есть

        arr.push({
            title: targetLower,  // регистр оригинала не сохраняем — берём lower
            count: data.allWikiTargets[targetLower]
        });
    }
    arr.sort(function(a, b) { return b.count - a.count; });
    return arr;
}


// =====================================================================
// ЧАСТЬ 3. ФОРМИРОВАНИЕ СЕКЦИЙ
// =====================================================================

function buildSummarySection(data) {
    var lines = [];
    lines.push("📊 Всего заметок: " + data.totalNotes);
    lines.push("📌 Закреплённых: " + data.pinnedCount);
    lines.push("📁 Коллекций: " + data.collectionsCount);
    lines.push("🏷 Уникальных тегов: " + Object.keys(data.tagsCounter).length);
    lines.push("🔗 Всего связей: " + data.totalLinks);

    var redLinks = findRedLinks(data);
    if (redLinks.length > 0) {
        lines.push("🚨 Красных ссылок: " + redLinks.length);
    }

    return lines.join("\n");
}

function buildTagsSection(data) {
    var tags = findTopTags(data);
    if (tags.length === 0) {
        return "🏷 Тегов нет.";
    }

    var lines = ["🏷 Топ тегов (по числу заметок):", ""];
    var limit = Math.min(tags.length, TOP_N);
    for (var i = 0; i < limit; i++) {
        var t = tags[i];
        lines.push("  " + (i + 1) + ". " + t.tag + " — " + t.count + " заметок");
    }
    if (tags.length > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (tags.length - TOP_N) + " тегов");
    }
    return lines.join("\n");
}

function buildHubsSection(data) {
    var hubs = findHubs(data);
    if (hubs.length === 0) {
        return "🔗 Хабов нет — ни на одну заметку не ссылаются через [[...]].";
    }

    var lines = ["🔗 Хабы (заметки с максимумом входящих ссылок):", ""];
    var limit = Math.min(hubs.length, TOP_N);
    for (var i = 0; i < limit; i++) {
        var h = hubs[i];
        lines.push("  " + (i + 1) + ". «" + ellipsize(h.title) + "» — " + h.count + " " + plural(h.count, "ссылка", "ссылки", "ссылок"));
    }
    if (hubs.length > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (hubs.length - TOP_N));
    }
    return lines.join("\n");
}

function buildIsolatedSection(data) {
    var isolated = findIsolated(data);
    if (isolated.length === 0) {
        return "🏝 Изолированных заметок нет — у всех есть теги или входящие ссылки.";
    }

    var lines = ["🏝 Изолированные заметки (без связей и тегов):", ""];
    var limit = Math.min(isolated.length, TOP_N);
    for (var i = 0; i < limit; i++) {
        var meta = isolated[i];
        lines.push("  • «" + ellipsize(meta.title || "Без названия") + "»");
    }
    if (isolated.length > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (isolated.length - TOP_N));
    }
    lines.push("");
    lines.push("Всего: " + isolated.length);
    return lines.join("\n");
}

function buildRedLinksSection(data) {
    var red = findRedLinks(data);
    if (red.length === 0) {
        return "🚨 Красных ссылок нет — все [[...]] указывают на существующие заметки.";
    }

    var lines = ["🚨 Красные ссылки (упомянуты, но заметок нет):", ""];
    var limit = Math.min(red.length, TOP_N);
    for (var i = 0; i < limit; i++) {
        var r = red[i];
        lines.push("  • [[" + ellipsize(r.title) + "]] — " + r.count + " " + plural(r.count, "упоминание", "упоминания", "упоминаний"));
    }
    if (red.length > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (red.length - TOP_N));
    }
    lines.push("");
    lines.push("Всего: " + red.length);
    return lines.join("\n");
}

function buildDuplicatesSection(data) {
    var dups = findDuplicates(data);
    if (dups.length === 0) {
        return "⚠ Дубликатов заголовков нет.";
    }

    var lines = ["⚠ Дубликаты заголовков:", ""];
    var limit = Math.min(dups.length, TOP_N);
    for (var i = 0; i < limit; i++) {
        var d = dups[i];
        lines.push("  • «" + ellipsize(d.title) + "» — " + d.count + " заметки");
    }
    if (dups.length > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (dups.length - TOP_N));
    }
    lines.push("");
    lines.push("Всего: " + dups.length);
    return lines.join("\n");
}

function buildNoCollectionSection(data) {
    var count = data.withoutCollection.length;
    if (count === 0) {
        return "📂 Все заметки распределены по коллекциям.";
    }

    var lines = ["📂 Заметки без коллекции:", ""];

    // Показываем первые TOP_N с заголовками.
    var limit = Math.min(count, TOP_N);
    for (var i = 0; i < limit; i++) {
        var id = data.withoutCollection[i];
        var meta = data.notesById[id];
        var title = meta ? (meta.title || "Без названия") : id;
        lines.push("  • «" + ellipsize(title) + "»");
    }
    if (count > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (count - TOP_N));
    }
    lines.push("");
    lines.push("Всего: " + count);
    return lines.join("\n");
}

function buildEmptySection(data) {
    var count = data.emptyNotes.length;
    if (count === 0) {
        return "📄 Пустых заметок нет.";
    }

    var lines = ["📄 Пустые заметки (без заголовка и тела):", ""];
    var limit = Math.min(count, TOP_N);
    for (var i = 0; i < limit; i++) {
        lines.push("  • id: " + data.emptyNotes[i]);
    }
    if (count > TOP_N) {
        lines.push("");
        lines.push("... и ещё " + (count - TOP_N));
    }
    lines.push("");
    lines.push("Всего: " + count);
    return lines.join("\n");
}

/**
 * Плюрализация для русского: 1 ссылка, 2 ссылки, 5 ссылок.
 * Простая эвристика по последней цифре.
 */
function plural(n, one, few, many) {
    var mod10 = n % 10;
    var mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return one;
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
    return many;
}


// =====================================================================
// ЧАСТЬ 4. КОНВЕЙЕР
// =====================================================================

/**
 * Показывает секцию, потом спрашивает «Продолжить?».
 * Возвращает true, если пользователь хочет продолжить, false — если нет.
 */
function showSectionAndAsk(title, text, askNext, nextLabel) {
    if (!askNext) {
        oniks.dialog.alert(text, title);
        return false;
    }
    return oniks.dialog.confirm(text + "\n\n" + "───\n\n" + nextLabel, title);
}

/**
 * Полный отчёт конвейером.
 */
function runFullReport() {
    var data = collectData();
    if (data.empty) {
        oniks.dialog.alert("Заметок нет.", "📊 Сводка");
        return;
    }

    var steps = [
        { title: "📊 Сводка", builder: buildSummarySection },
        { title: "🏷 Топ тегов", builder: buildTagsSection },
        { title: "🔗 Хабы", builder: buildHubsSection },
        { title: "🏝 Изолированные", builder: buildIsolatedSection },
        { title: "🚨 Красные ссылки", builder: buildRedLinksSection },
        { title: "⚠ Дубликаты", builder: buildDuplicatesSection },
        { title: "📂 Без коллекции", builder: buildNoCollectionSection },
        { title: "📄 Пустые", builder: buildEmptySection }
    ];

    for (var i = 0; i < steps.length; i++) {
        var step = steps[i];
        var text = step.builder(data);
        var isLast = (i === steps.length - 1);

        if (isLast) {
            oniks.dialog.alert(text, step.title);
            break;
        }

        var next = steps[i + 1];
        var continueNext = oniks.dialog.confirm(
            text + "\n\n" + "───\n\nПоказать «" + next.title + "»?",
            step.title
        );
        if (!continueNext) {
            oniks.log.info("Dashboard: конвейер прерван на «" + step.title + "»");
            break;
        }
    }
}

/**
 * Показать одну секцию.
 */
function showSingleSection(title, builder) {
    var data = collectData();
    if (data.empty) {
        oniks.dialog.alert("Заметок нет.", "📊 Сводка");
        return;
    }
    var text = builder(data);
    oniks.dialog.alert(text, title);
}


// =====================================================================
// ЧАСТЬ 5. КОМАНДЫ
// =====================================================================

oniks.commands.register({
    id: "dashboard-full",
    title: "Сводка: полный отчёт",
    handler: function() {
        oniks.log.info("Dashboard: полный отчёт");
        runFullReport();
    }
});

oniks.commands.register({
    id: "dashboard-summary",
    title: "Сводка: общая статистика",
    handler: function() {
        showSingleSection("📊 Сводка", buildSummarySection);
    }
});

oniks.commands.register({
    id: "dashboard-tags",
    title: "Сводка: топ тегов",
    handler: function() {
        showSingleSection("🏷 Топ тегов", buildTagsSection);
    }
});

oniks.commands.register({
    id: "dashboard-hubs",
    title: "Сводка: хабы",
    handler: function() {
        showSingleSection("🔗 Хабы", buildHubsSection);
    }
});

oniks.commands.register({
    id: "dashboard-isolated",
    title: "Сводка: изолированные",
    handler: function() {
        showSingleSection("🏝 Изолированные", buildIsolatedSection);
    }
});

oniks.commands.register({
    id: "dashboard-redlinks",
    title: "Сводка: красные ссылки",
    handler: function() {
        showSingleSection("🚨 Красные ссылки", buildRedLinksSection);
    }
});

oniks.commands.register({
    id: "dashboard-duplicates",
    title: "Сводка: дубликаты заголовков",
    handler: function() {
        showSingleSection("⚠ Дубликаты", buildDuplicatesSection);
    }
});

oniks.commands.register({
    id: "dashboard-no-collection",
    title: "Сводка: без коллекции",
    handler: function() {
        showSingleSection("📂 Без коллекции", buildNoCollectionSection);
    }
});

oniks.commands.register({
    id: "dashboard-empty",
    title: "Сводка: пустые заметки",
    handler: function() {
        showSingleSection("📄 Пустые", buildEmptySection);
    }
});


// =====================================================================
// INIT
// =====================================================================

oniks.log.info("Сводка (Dashboard) loaded, commands: 9");
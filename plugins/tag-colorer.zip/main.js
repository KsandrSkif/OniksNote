// =====================================================================
// Tag Colorer — плагин для Оникса
//
// Красит узлы графа по ВСЕМ тегам заметки:
//   - один тег → цвет тега
//   - несколько → средний (смешанный) оттенок
//
// Красит рёбра по ОБЩИМ тегам двух заметок:
//   - нет общих → дефолт (серый)
//   - один общий → цвет тега
//   - несколько общих → средний оттенок + жирнее
//
// Палитра — та же, что в ядре Оникса (GraphTagColorPalette).
// Хеш-алгоритм — Java String.hashCode(), реплицирован в JS.
//
// ВАЖНО: Rhino 1.7.14 — ES5. Без lookbehind, стрелок, let/const.
// ВАЖНО: try/catch НЕ работает.
// ВАЖНО: .call() на методах oniks.* НЕ работает.
// =====================================================================


// =====================================================================
// ЧАСТЬ 1. ПАЛИТРА (копия GraphTagColorPalette)
// =====================================================================

/**
 * 12 цветов Material Design 300 — та же палитра, что в ядре Оникса.
 * Порядок ВАЖЕН: он определяет, какой цвет достанется тегу.
 */
var PALETTE = [
    "#E57373", // красный
    "#F06292", // розовый
    "#BA68C8", // фиолетовый
    "#7986CB", // индиго
    "#64B5F6", // синий
    "#4DD0E1", // голубой
    "#4DB6AC", // бирюзовый
    "#81C784", // зелёный
    "#AED581", // лаймовый
    "#FFD54F", // жёлтый
    "#FFB74D", // оранжевый
    "#A1887F"  // коричневый
];

/**
 * Реплика Java String.hashCode() — чтобы получить тот же индекс палитры,
 * что и ядро Оникса.
 */
function javaHashCode(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) {
        h = (h * 31 + str.charCodeAt(i)) | 0;  // 32-bit int overflow
    }
    return h;
}

/**
 * Возвращает hex-цвет для тега.
 * Детерминирован: один тег → один цвет.
 */
function colorForTag(tag) {
    if (!tag || tag.length === 0) return PALETTE[0];
    var normalized = tag.toLowerCase();
    var hash = javaHashCode(normalized);
    var index = Math.abs(hash) % PALETTE.length;
    return PALETTE[index];
}

/**
 * Парсит hex (#RRGGBB) в {r, g, b}.
 */
function parseHex(hex) {
    var h = hex.substring(1);  // убираем #
    return {
        r: parseInt(h.substring(0, 2), 16),
        g: parseInt(h.substring(2, 4), 16),
        b: parseInt(h.substring(4, 6), 16)
    };
}

/**
 * Собирает hex из {r, g, b}.
 */
function toHex(r, g, b) {
    var rr = Math.round(r);
    var gg = Math.round(g);
    var bb = Math.round(b);
    var hr = ("0" + rr.toString(16)).slice(-2);
    var hg = ("0" + gg.toString(16)).slice(-2);
    var hb = ("0" + bb.toString(16)).slice(-2);
    return "#" + hr + hg + hb;
}

/**
 * Смешивает массив цветов в один средний.
 * Если массив пуст — возвращает null.
 */
function mixColors(colors) {
    if (!colors || colors.length === 0) return null;
    if (colors.length === 1) return colors[0];

    var r = 0, g = 0, b = 0;
    for (var i = 0; i < colors.length; i++) {
        var c = parseHex(colors[i]);
        r += c.r;
        g += c.g;
        b += c.b;
    }
    var n = colors.length;
    return toHex(r / n, g / n, b / n);
}


// =====================================================================
// ЧАСТЬ 2. ЦВЕТ УЗЛА — СМЕСЬ ВСЕХ ТЕГОВ
// =====================================================================

/**
 * Возвращает цвет узла — средний оттенок всех его тегов.
 */
function nodeColor(node) {
    if (!node || !node.tags || node.tags.length === 0) {
        return null;  // дефолт
    }

    var colors = [];
    for (var i = 0; i < node.tags.length; i++) {
        var tag = node.tags[i];
        if (tag && tag.length > 0) {
            colors.push(colorForTag(tag));
        }
    }

    if (colors.length === 0) return null;
    return mixColors(colors);
}


// =====================================================================
// ЧАСТЬ 3. ЦВЕТ РЕБРА — ПО ОБЩИМ ТЕГАМ
// =====================================================================

/**
 * Возвращает список общих тегов двух узлов (регистронезависимо).
 */
function sharedTags(fromTags, toTags) {
    if (!fromTags || !toTags) return [];
    if (fromTags.length === 0 || toTags.length === 0) return [];

    // Приводим toTags к lower-case Set.
    var toLower = {};
    for (var i = 0; i < toTags.length; i++) {
        var t = toTags[i];
        if (t && t.length > 0) {
            toLower[t.toLowerCase()] = true;
        }
    }

    var result = [];
    for (var j = 0; j < fromTags.length; j++) {
        var f = fromTags[j];
        if (f && f.length > 0 && toLower[f.toLowerCase()]) {
            // Оригинальный регистр сохраняем.
            result.push(f);
        }
    }
    return result;
}

/**
 * Возвращает стиль ребра: цвет по общим тегам, толщину по их количеству.
 */
function edgeStyleFor(fromTags, toTags) {
    var shared = sharedTags(fromTags, toTags);
    if (shared.length === 0) {
        return null;  // дефолт (серый)
    }

    // Цвета общих тегов.
    var colors = [];
    for (var i = 0; i < shared.length; i++) {
        colors.push(colorForTag(shared[i]));
    }
    var color = mixColors(colors);

    // Чем больше общих тегов — тем жирнее ребро.
    var widthMultiplier = 1.0;
    if (shared.length >= 2) widthMultiplier = 1.5;
    if (shared.length >= 3) widthMultiplier = 2.0;

    return {
        color: color,
        widthMultiplier: widthMultiplier
    };
}


// =====================================================================
// ЧАСТЬ 4. РЕГИСТРАЦИЯ СТИЛЕРА
// =====================================================================

oniks.graph.register({
    id: "tag-colorer",
    nodeStyler: function (node) {
        var color = nodeColor(node);
        if (color === null) return null;
        return { color: color };
    },
    edgeStyler: function (edge) {
        return edgeStyleFor(edge.fromTags, edge.toTags);
    }
});


// =====================================================================
// INIT
// =====================================================================

oniks.log.info("Tag Colorer loaded");
// =====================================================================
// Constellation — визуальная тема графа для Оникса
//
// Что делает:
//  - раскрашивает узлы по правилам «тег → цвет» с приоритетом;
//  - подсвечивает хабы (узлы с большим числом связей) ярче;
//  - помечает изолированные заметки в подписях (○, ★).
//
// Правила хранятся в oniks.storage как JSON. Максимум 10 правил.
// Приоритет — порядок в списке: первый матч выигрывает.
//
// ВАЖНО: Rhino 1.7.14 — ES5. Без lookbehind, стрелок, let/const.
// =====================================================================


// =====================================================================
// ЧАСТЬ 1. КОНФИГ И КОНСТАНТЫ
// =====================================================================

var STORAGE_KEY_RULES = "rules";
var STORAGE_KEY_HUBS_ENABLED = "hubsEnabled";
var STORAGE_KEY_ISOLATED_LABELS = "isolatedLabels";

var MAX_RULES = 10;

// Пороги хабов.
var HUB_DEGREE_LOW = 5;       // >= 5 → повышенный радиус + контур
var HUB_DEGREE_HIGH = 10;     // >= 10 → ещё больше + звёздочка

// Множители радиуса для хабов.
var HUB_RADIUS_LOW = 1.3;
var HUB_RADIUS_HIGH = 1.6;

// Цвета контуров хабов.
var HUB_BORDER_LOW = "#FFFFFF";
var HUB_BORDER_HIGH = "#FFD700";

// Пары hex-цветов: правило принимает #RRGGBB или #AARRGGBB.
var HEX_COLOR_REGEX = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;


// =====================================================================
// ЧАСТЬ 2. ХРАНИЛИЩЕ И КЭШ
// =====================================================================

// Кэш правил. null — не загружен. Массив — актуален.
var RULES_CACHE = null;

// Кэш флагов настроек.
var HUBS_ENABLED_CACHE = null;
var ISOLATED_LABELS_CACHE = null;

/**
 * Загружает правила из oniks.storage. Кэширует.
 */
function loadRules() {
    if (RULES_CACHE !== null) return RULES_CACHE;

    try {
        var raw = oniks.storage.get(STORAGE_KEY_RULES);
        if (!raw) {
            RULES_CACHE = [];
            return RULES_CACHE;
        }
        var parsed = JSON.parse(raw);
        if (!parsed || typeof parsed.length !== "number") {
            RULES_CACHE = [];
        } else {
            RULES_CACHE = parsed;
        }
    } catch (e) {
        oniks.log.warn("Constellation: loadRules error: " + e.message);
        RULES_CACHE = [];
    }
    return RULES_CACHE;
}

/**
 * Сохраняет правила. Инвалидирует кэш.
 */
function saveRules(rules) {
    try {
        oniks.storage.set(STORAGE_KEY_RULES, JSON.stringify(rules));
        RULES_CACHE = null;
    } catch (e) {
        oniks.log.error("Constellation: saveRules error: " + e.message);
    }
}

/**
 * Флаг «хабы подсвечивать». По умолчанию — true.
 */
function isHubsEnabled() {
    if (HUBS_ENABLED_CACHE !== null) return HUBS_ENABLED_CACHE;
    try {
        var raw = oniks.storage.get(STORAGE_KEY_HUBS_ENABLED);
        HUBS_ENABLED_CACHE = (raw === null || raw === undefined) ? true : (raw === "true");
    } catch (e) {
        HUBS_ENABLED_CACHE = true;
    }
    return HUBS_ENABLED_CACHE;
}

function setHubsEnabled(enabled) {
    try {
        oniks.storage.set(STORAGE_KEY_HUBS_ENABLED, enabled ? "true" : "false");
    } catch (e) {
        oniks.log.error("Constellation: setHubsEnabled error: " + e.message);
    }
    HUBS_ENABLED_CACHE = enabled;
}

/**
 * Флаг «метки изолированных». По умолчанию — true.
 */
function isIsolatedLabelsEnabled() {
    if (ISOLATED_LABELS_CACHE !== null) return ISOLATED_LABELS_CACHE;
    try {
        var raw = oniks.storage.get(STORAGE_KEY_ISOLATED_LABELS);
        ISOLATED_LABELS_CACHE = (raw === null || raw === undefined) ? true : (raw === "true");
    } catch (e) {
        ISOLATED_LABELS_CACHE = true;
    }
    return ISOLATED_LABELS_CACHE;
}

function setIsolatedLabelsEnabled(enabled) {
    try {
        oniks.storage.set(STORAGE_KEY_ISOLATED_LABELS, enabled ? "true" : "false");
    } catch (e) {
        oniks.log.error("Constellation: setIsolatedLabelsEnabled error: " + e.message);
    }
    ISOLATED_LABELS_CACHE = enabled;
}


// =====================================================================
// ЧАСТЬ 3. УТИЛИТЫ
// =====================================================================

function trim(s) {
    return s.replace(/^\s+|\s+$/g, "");
}

function normalizeTag(tag) {
    return trim(String(tag)).toLowerCase();
}

function isValidHexColor(color) {
    return HEX_COLOR_REGEX.test(color);
}

/**
 * Нормализует hex: добавляет альфу, если её нет.
 * #RRGGBB → #FFRRGGBB (непрозрачный).
 */
function normalizeHex(color) {
    var c = trim(color).toUpperCase();
    if (c.length === 7) {
        return "#FF" + c.substring(1);
    }
    return c;
}

/**
 * Проверяет, есть ли у заметки тег (без учёта регистра).
 */
function hasTag(node, tag) {
    if (!node.tags || node.tags.length === 0) return false;
    var target = normalizeTag(tag);
    for (var i = 0; i < node.tags.length; i++) {
        if (normalizeTag(node.tags[i]) === target) return true;
    }
    return false;
}

/**
 * Находит первое подходящее правило для узла.
 * Возвращает правило или null.
 */
function findMatchingRule(node, rules) {
    if (!rules || rules.length === 0) return null;
    for (var i = 0; i < rules.length; i++) {
        var rule = rules[i];
        if (!rule || !rule.tag || !rule.color) continue;
        if (hasTag(node, rule.tag)) return rule;
    }
    return null;
}


// =====================================================================
// ЧАСТЬ 4. СТИЛЕРЫ
// =====================================================================

/**
 * Стилер узлов. Применяет правило или подсветку хаба.
 */
function nodeStyler(node) {
    if (!node) return null;

    var rules = loadRules();
    var rule = findMatchingRule(node, rules);

    var style = {};

    // 1. Цвет от правила.
    if (rule) {
        style.color = rule.color;
    }

    // 2. Подсветка хаба.
    if (isHubsEnabled() && node.degree >= HUB_DEGREE_LOW) {
        if (node.degree >= HUB_DEGREE_HIGH) {
            style.radiusMultiplier = HUB_RADIUS_HIGH;
            style.borderColor = HUB_BORDER_HIGH;
        } else {
            style.radiusMultiplier = HUB_RADIUS_LOW;
            style.borderColor = HUB_BORDER_LOW;
        }
    }

    // Если ничего не изменили — вернуть null (не трогать дефолт).
    if (style.color === undefined &&
        style.radiusMultiplier === undefined &&
        style.borderColor === undefined) {
        return null;
    }

    return style;
}

/**
 * Стилер подписей. Добавляет метки для изолированных и хабов.
 */
function labelStyler(node) {
    if (!node) return null;
    if (!isIsolatedLabelsEnabled()) return null;
    if (!node.title) return null;

    if (node.degree === 1) {
        return "○ " + node.title;
    }
    if (node.degree >= HUB_DEGREE_HIGH) {
        return "★ " + node.title;
    }
    return null;
}


// =====================================================================
// ЧАСТЬ 5. РАБОТА С ПРАВИЛАМИ
// =====================================================================

/**
 * Добавляет правило. Если тег уже есть — перезаписывает цвет
 * и поднимает правило вверх (приоритет).
 *
 * Возвращает результат: {ok: boolean, reason: string}.
 */
function addRule(tag, color) {
    var cleanTag = trim(String(tag || ""));
    var cleanColor = trim(String(color || ""));

    if (cleanTag.length === 0) {
        return { ok: false, reason: "empty_tag" };
    }
    if (!isValidHexColor(cleanColor)) {
        return { ok: false, reason: "invalid_color" };
    }

    var normalizedColor = normalizeHex(cleanColor);
    var normalizedTag = normalizeTag(cleanTag);

    var rules = loadRules().slice();  // копия

    // Удаляем старое правило с этим тегом (если было).
    var filtered = [];
    for (var i = 0; i < rules.length; i++) {
        if (normalizeTag(rules[i].tag) !== normalizedTag) {
            filtered.push(rules[i]);
        }
    }

    // Лимит проверяем после удаления дубликата.
    if (filtered.length >= MAX_RULES) {
        return { ok: false, reason: "limit_reached" };
    }

    // Новое правило — в начало (высший приоритет).
    var newRule = { tag: cleanTag, color: normalizedColor };
    var updated = [newRule].concat(filtered);

    saveRules(updated);

    return { ok: true, reason: "added", rule: newRule };
}

/**
 * Удаляет правило по индексу.
 */
function removeRule(index) {
    var rules = loadRules().slice();
    if (index < 0 || index >= rules.length) {
        return { ok: false, reason: "invalid_index" };
    }
    var removed = rules[index];
    rules.splice(index, 1);
    saveRules(rules);
    return { ok: true, reason: "removed", rule: removed };
}

/**
 * Сбрасывает все правила.
 */
function resetRules() {
    saveRules([]);
    return { ok: true, reason: "reset" };
}

/**
 * Форматирует список правил для диалога.
 */
function formatRules(rules) {
    if (!rules || rules.length === 0) {
        return "Правил нет.\n\nДобавьте правило командой «Constellation: добавить правило».";
    }
    var lines = ["Активные правила (по приоритету):", ""];
    for (var i = 0; i < rules.length; i++) {
        var r = rules[i];
        lines.push((i + 1) + ". " + r.tag + "  →  " + r.color);
    }
    lines.push("");
    lines.push("Всего: " + rules.length + " / " + MAX_RULES);
    return lines.join("\n");
}


// =====================================================================
// ЧАСТЬ 6. КОМАНДЫ
// =====================================================================

oniks.commands.register({
    id: "constellation-list",
    title: "Constellation: показать правила",
    handler: function() {
        var rules = loadRules();
        var message = formatRules(rules);
        message += "\n\nПодсветка хабов: " + (isHubsEnabled() ? "вкл" : "выкл");
        message += "\nМетки изолированных: " + (isIsolatedLabelsEnabled() ? "вкл" : "выкл");
        oniks.dialog.alert(message, "Constellation");
    }
});

oniks.commands.register({
    id: "constellation-add",
    title: "Constellation: добавить правило",
    handler: function() {
        var tag = oniks.dialog.prompt(
            "Введите тег (например: важно).\n\nРегистр не важен.",
            "",
            "Constellation: тег"
        );
        if (!tag) return;

        var color = oniks.dialog.prompt(
            "Введите цвет в формате #RRGGBB.\n\nПримеры:\n#E57373 — красный\n#64B5F6 — синий\n#FFD54F — жёлтый",
            "#E57373",
            "Constellation: цвет"
        );
        if (!color) return;

        var result = addRule(tag, color);

        if (!result.ok) {
            if (result.reason === "empty_tag") {
                oniks.dialog.alert("Тег пустой.", "Constellation");
            } else if (result.reason === "invalid_color") {
                oniks.dialog.alert("Цвет должен быть в формате #RRGGBB или #AARRGGBB.", "Constellation");
            } else if (result.reason === "limit_reached") {
                oniks.dialog.alert("Достигнут лимит правил (" + MAX_RULES + "). Удалите одно — потом добавьте новое.", "Constellation");
            } else {
                oniks.dialog.alert("Не удалось добавить правило.", "Constellation");
            }
            return;
        }

        oniks.log.info("Constellation: added rule " + tag + " → " + result.rule.color);
        oniks.dialog.alert(
            "Правило добавлено:\n\n" + result.rule.tag + "  →  " + result.rule.color +
            "\n\nСтиль применится при следующем открытии графа.",
            "Constellation"
        );
    }
});

oniks.commands.register({
    id: "constellation-remove",
    title: "Constellation: удалить правило",
    handler: function() {
        var rules = loadRules();
        if (rules.length === 0) {
            oniks.dialog.alert("Правил нет.", "Constellation");
            return;
        }

        var labels = [];
        for (var i = 0; i < rules.length; i++) {
            labels.push((i + 1) + ". " + rules[i].tag + "  →  " + rules[i].color);
        }

        var chosen = oniks.dialog.choose(
            "Выберите правило для удаления:",
            labels,
            "Constellation: удалить"
        );
        if (chosen === null || chosen === undefined || chosen < 0) return;

        var result = removeRule(chosen);
        if (!result.ok) {
            oniks.dialog.alert("Не удалось удалить правило.", "Constellation");
            return;
        }

        oniks.log.info("Constellation: removed rule " + result.rule.tag);
        oniks.dialog.alert(
            "Правило удалено:\n\n" + result.rule.tag + "  →  " + result.rule.color,
            "Constellation"
        );
    }
});

oniks.commands.register({
    id: "constellation-reset",
    title: "Constellation: сбросить правила",
    handler: function() {
        var rules = loadRules();
        if (rules.length === 0) {
            oniks.dialog.alert("Правил нет.", "Constellation");
            return;
        }
        if (!oniks.dialog.confirm(
            "Удалить все правила (" + rules.length + ")?\n\nДействие необратимо.",
            "Constellation: сброс"
        )) return;

        resetRules();
        oniks.log.info("Constellation: rules reset");
        oniks.dialog.alert("Все правила удалены.", "Constellation");
    }
});

oniks.commands.register({
    id: "constellation-hubs-toggle",
    title: "Constellation: подсветка хабов",
    handler: function() {
        var current = isHubsEnabled();
        var next = !current;

        var message = "Текущее состояние: " + (current ? "вкл" : "выкл") +
            "\n\nПереключить на: " + (next ? "вкл" : "выкл") + "?" +
            "\n\nХабы — узлы с 5+ связями. Получают увеличенный радиус и контур." +
            "\n10+ связей — золотой контур и метка ★.";

        if (oniks.dialog.confirm(message, "Constellation: хабы")) {
            setHubsEnabled(next);
            oniks.log.info("Constellation: hubs = " + next);
            oniks.dialog.alert(
                "Подсветка хабов: " + (next ? "вкл" : "выкл") +
                "\n\nПрименится при следующем открытии графа.",
                "Constellation"
            );
        }
    }
});

oniks.commands.register({
    id: "constellation-isolated-toggle",
    title: "Constellation: метки изолированных",
    handler: function() {
        var current = isIsolatedLabelsEnabled();
        var next = !current;

        var message = "Текущее состояние: " + (current ? "вкл" : "выкл") +
            "\n\nПереключить на: " + (next ? "вкл" : "выкл") + "?" +
            "\n\nИзолированные узлы (1 связь) получают метку ○ в подписи." +
            "\nХабы (10+ связей) — метку ★.";

        if (oniks.dialog.confirm(message, "Constellation: метки")) {
            setIsolatedLabelsEnabled(next);
            oniks.log.info("Constellation: isolated labels = " + next);
            oniks.dialog.alert(
                "Метки: " + (next ? "вкл" : "выкл") +
                "\n\nПрименится при следующем открытии графа.",
                "Constellation"
            );
        }
    }
});


// =====================================================================
// ЧАСТЬ 7. РЕГИСТРАЦИЯ ГРАФ-СТИЛЕРА
// =====================================================================

oniks.graph.register({
    id: "constellation",
    nodeStyler: nodeStyler,
    labelStyler: labelStyler
});


// =====================================================================
// INIT
// =====================================================================

oniks.log.info("Constellation loaded, rules: " + loadRules().length +
    ", hubs: " + isHubsEnabled() +
    ", isolated: " + isIsolatedLabelsEnabled());
// =====================================================================
// Smart Improver — плагин для Оникса
//
// Улучшает текст, наговорённый голосом:
//  - убирает слова-паразиты и повторы
//  - нормализует пробелы и пунктуацию
//  - расставляет заглавные буквы
//  - структурирует перечисления в списки
//  - выносит задачи в чек-лист (с учётом времени глагола)
//  - добавляет разрывы параграфов по маркерам темы
//
// Работает полностью офлайн, на алгоритмах, без LLM.
//
// ВАЖНО: Rhino 1.7.14 — ES5. Без lookbehind, стрелок, let/const.
// =====================================================================


// =====================================================================
// ЧАСТЬ 1. КОНФИГ И СЛОВАРИ
// =====================================================================

var CONFIG_KEY = "config";

var DEFAULT_CONFIG = {
    aggressiveness: "normal",  // light | normal | aggressive
    cleanFillers: true,
    cleanDuplicates: true,
    fixCapitalization: true,
    fixPunctuation: true,
    structureEnumerations: true,
    structureTasks: true,
    structureTopicBreaks: true,
    customFillers: []
};

function loadConfig() {
    try {
        var stored = oniks.storage.get(CONFIG_KEY);
        if (!stored) return DEFAULT_CONFIG;
        var parsed = JSON.parse(stored);
        var result = {};
        for (var k in DEFAULT_CONFIG) {
            if (DEFAULT_CONFIG.hasOwnProperty(k)) {
                result[k] = (parsed[k] !== undefined) ? parsed[k] : DEFAULT_CONFIG[k];
            }
        }
        return result;
    } catch (e) {
        oniks.log.warn("Config load error: " + e.message);
        return DEFAULT_CONFIG;
    }
}

function saveConfig(cfg) {
    try {
        oniks.storage.set(CONFIG_KEY, JSON.stringify(cfg));
    } catch (e) {
        oniks.log.error("Config save error: " + e.message);
    }
}

// Слова-паразиты.
// Однобуквенные — только «э», «м». Союзы «а», «и», «о», «у» НЕ трогаем.
var FILLERS_LIGHT = [
    "эээ", "ээ", "э",
    "ммм", "мм", "м"
];

var FILLERS_NORMAL = FILLERS_LIGHT.concat([
    "ну", "вот", "значит", "типа", "как бы", "короче",
    "в общем", "это самое", "того", "эка", "така",
    "так", "ладно"
]);

var FILLERS_AGGRESSIVE = FILLERS_NORMAL.concat([
    "кстати", "вообще", "собственно", "в принципе",
    "понимаешь", "понимаете", "видишь", "видите"
]);

// Маркеры задач (инфинитив, модальные глаголы, императив).
var TASK_MARKERS = [
    // Модальные
    "надо", "нужно", "необходимо", "следует",
    "должен", "должна", "должны", "обязательно",

    // Инфинитивы
    "сделать", "не забыть", "не забудь",
    "позвонить", "написать", "купить", "проверить",

    // Императивы (топ-10, остальное ловит isVerbForm через fallback)
    "позвони", "напиши", "купи", "проверь", "сделай",
    "отправь", "посмотри", "убери", "закажи", "приготовь"
];

// Модальные маркеры, которые можно удалять где угодно (в начале и в середине).
var REMOVABLE_TASK_MARKERS = [
    "надо", "нужно", "следует", "необходимо",
    "не забыть", "не забудь", "обязательно"
];

// Маркеры прошедшего времени.
var PAST_TENSE_MARKERS = [
    "было", "был", "была", "были",
    "раньше", "вчера", "позавчера",
    "сделал", "сделала", "сделали",
    "купил", "купила", "купили",
    "позвонил", "позвонила", "позвонили",
    "написал", "написала", "написали",
    "проверил", "проверила", "проверили"
];

// Маркеры модальных глаголов (для проверки «надо было…»).
var MODAL_MARKERS = [
    "надо", "нужно", "следует", "должен", "должна", "должны",
    "необходимо", "обязательно"
];

// Маркеры выполненного действия. Такие задачи помечаются [x].
var DONE_MARKERS = [
    "сделано", "выполнено", "готово",
    "done", "✅", "✔", "☑"
];

// Слова-индикаторы размышления. Если они есть — предложение НЕ задача.
var REFLECTION_MARKERS = [
    "подумал", "подумала", "подумали",
    "решил", "решила", "решили",
    "понял", "поняла", "поняли",
    "заметил", "заметила", "заметили"
];

// Маркеры темы. Разрыв параграфа по ним.
var TOPIC_MARKERS = [
    "кстати", "по поводу", "насчёт", "на счет",
    "кроме того", "а вот", "что касается",
    "с другой стороны", "тем не менее"
];

// Вводные маркеры темы, которые можно убирать из начала задачи.
var STRIPPABLE_TOPIC_MARKERS = [
    "кстати", "кроме того", "а вот", "тем не менее"
];

// Частые императивы 2-го лица. Используются в isVerbForm для splitComplexTask.
// Список сознательно короткий: покрывает 80% случаев, не ловит сущ.
var IMPERATIVE_VERBS = [
    "купи", "позвони", "напиши", "проверь", "сделай", "отправь",
    "закажи", "посмотри", "почини", "убери", "поли", "помой",
    "приготовь", "уберись", "прочитай", "выучи", "сдай", "оплати",
    "скажи", "спроси", "уточни", "напомни", "запиши", "сохрани",
    "открой", "закрой", "включи", "выключи", "настрой", "установи",
    "обнови", "удали", "перенеси", "отмени", "подтверди"
];

// Маркеры перечислений.
var ENUMERATION_MARKERS = {
    // существующие...
    "во-первых": 1, "во-вторых": 2, "в-третьих": 3,
    "в-четвёртых": 4, "в-пятых": 5,
    "первое": 1, "второе": 2, "третье": 3,
    "четвёртое": 4, "пятое": 5,
    "в первую очередь": 1,
    "во вторую очередь": 2,
    "в третью очередь": 3,
    "в четвёртую очередь": 4,
    "в пятую очередь": 5,
    "сначала": 1,
    "потом": 2,
    "затем": 3,
    "далее": 4,
    "наконец": 5,
    // НОВЫЕ:
    "в начале": 1,
    "в дальнейшем": 3,
    "после этого": 3,
    "в итоге": 5,
    "в конце": 5
};


// =====================================================================
// ЧАСТЬ 2. УТИЛИТЫ
// =====================================================================

function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function trim(s) {
    return s.replace(/^\s+|\s+$/g, "");
}

function capitalizeFirst(s) {
    if (!s || s.length === 0) return s;
    var first = s.charAt(0);
    var upper = first.toUpperCase();
    if (first === upper) return s;
    return upper + s.substring(1);
}

/**
 * Разбивает текст на предложения.
 * Без lookbehind (Rhino 1.7.14 его не поддерживает).
 */
function splitSentences(text) {
    var result = [];
    var buffer = "";
    for (var i = 0; i < text.length; i++) {
        var c = text.charAt(i);
        buffer += c;
        if (c === "." || c === "!" || c === "?" || c === "…") {
            var next = (i + 1 < text.length) ? text.charAt(i + 1) : "";
            if (next === "" || /\s/.test(next)) {
                result.push(buffer.replace(/\s+$/, ""));
                buffer = "";
                while (i + 1 < text.length && /\s/.test(text.charAt(i + 1))) {
                    i++;
                }
            }
        }
    }
    if (buffer.replace(/\s+$/, "").length > 0) {
        result.push(buffer.replace(/\s+$/, ""));
    }
    return result;
}

/**
 * Проверяет, есть ли в строке слово-маркер.
 */
function containsMarker(text, markers) {
    var lower = text.toLowerCase();
    for (var i = 0; i < markers.length; i++) {
        var marker = markers[i];
        var re = new RegExp("(^|\\s)" + escapeRegex(marker) + "(\\s|$|[,:!?.])");
        if (re.test(lower)) return true;
    }
    return false;
}

/**
 * Ищет конец предложения начиная с позиции from.
 * Возвращает индекс сразу после .!?…
 */
function findSentenceEnd(text, from) {
    for (var i = from; i < text.length; i++) {
        var c = text.charAt(i);
        if (c === "." || c === "!" || c === "?" || c === "…") {
            return i + 1;
        }
    }
    return text.length;
}


// =====================================================================
// ЧАСТЬ 3. ОЧИСТКА
// =====================================================================

function removeFillers(text, cfg) {
    var list;
    if (cfg.aggressiveness === "light") {
        list = FILLERS_LIGHT;
    } else if (cfg.aggressiveness === "aggressive") {
        list = FILLERS_AGGRESSIVE;
    } else {
        list = FILLERS_NORMAL;
    }
    list = list.concat(cfg.customFillers || []);

    var result = text;
    for (var i = 0; i < list.length; i++) {
        var word = list[i];
        var re = new RegExp(
            "(^|[\\s,.!?;:])" + escapeRegex(word) + "([\\s,.!?;:]|$)",
            "gi"
        );
        result = result.replace(re, function(match, before, after) {
            if (after === "" || /[.!?;:]/.test(after)) return before + after;
            return before;
        });
    }
    result = result.replace(/[ \t]{2,}/g, " ");
    result = result.replace(/\s+([,.!?;:])/g, "$1");
    result = result.replace(/([,.!?;:])\s*\1+/g, "$1");
    return result;
}

/**
 * Удаляет междометия-заминки (только звуки, не слова).
 */
function removeInterjections(text) {
    var list = ["эээ", "ээ", "э", "ммм", "мм", "м", "ааа", "аа"];
    var result = text;
    for (var i = 0; i < list.length; i++) {
        var word = list[i];
        var re = new RegExp(
            "(^|[\\s,.!?;:])" + escapeRegex(word) + "([\\s,.!?;:]|$)",
            "gi"
        );
        result = result.replace(re, function(match, before, after) {
            if (after === "" || /[.!?;:]/.test(after)) return before + after;
            return before;
        });
    }
    return result.replace(/[ \t]{2,}/g, " ");
}

function removeDuplicateWords(text) {
    var re = /\b([а-яёa-z]+)(\s+\1\b)+/gi;
    return text.replace(re, "$1");
}

function fixSpaces(text) {
    return text
        .replace(/[ \t]{2,}/g, " ")
        .replace(/[ \t]+$/gm, "")
        .replace(/^[ \t]+/gm, "");
}

function fixCapitalization(text) {
    // После .!?… — с заглавной.
    text = text.replace(/([.!?…]\s+)([а-яёa-z])/g, function(m, p, c) {
        return p + c.toUpperCase();
    });
    // Начало строки — с заглавной.
    text = text.replace(/^([а-яёa-z])/gm, function(m, c) {
        return c.toUpperCase();
    });
    // Опускаем заглавную у слов-связок в середине предложения.
    text = lowercaseMidSentence(text);
    return text;
}

/**
 * Добавляет точку в конце строки, если её нет.
 * Не добавляет точку, если строка короткая (до 5 слов) и следующая —
 * маркер структуры (список, заголовок): это заголовок секции, не предложение.
 */
function fixPunctuation(text) {
    var lines = text.split("\n");
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        var trimmed = line.replace(/\s+$/, "");
        if (trimmed.length === 0) continue;
        if (/^\s*(#|[-*+]|\d+\.|>|\||```)/.test(trimmed)) continue;
        if (/[.!?…:;]$/.test(trimmed)) continue;

        var nextTrimmed = "";
        for (var n = i + 1; n < lines.length; n++) {
            var candidate = lines[n].replace(/^\s+/, "");
            if (candidate.length > 0) {
                nextTrimmed = candidate;
                break;
            }
        }

        var wordCount = (trimmed.match(/\S+/g) || []).length;
        if (wordCount <= 5 &&
            nextTrimmed.length > 0 &&
            /^(#|[-*+]|\d+\.|>|\||```)/.test(nextTrimmed)) {
            lines[i] = trimmed;
            continue;
        }

        lines[i] = trimmed + ".";
    }
    return lines.join("\n");
}


// =====================================================================
// ЧАСТЬ 4. СТРУКТУРИРОВАНИЕ
// =====================================================================

function findEnumerationMarkers(text) {
    var markers = [];
    for (var marker in ENUMERATION_MARKERS) {
        if (!ENUMERATION_MARKERS.hasOwnProperty(marker)) continue;
        var re = new RegExp(
            "(^|[\\s,.!?;:])(" + escapeRegex(marker) + ")(?=[\\s,.!?;:]|$)",
            "gi"
        );
        var m;
        while ((m = re.exec(text)) !== null) {
            markers.push({
                marker: marker,
                markerStart: m.index + m[1].length,
                markerEnd: m.index + m[1].length + m[2].length
            });
            if (m.index === re.lastIndex) re.lastIndex++;
        }
    }
    markers.sort(function(a, b) { return a.markerStart - b.markerStart; });
    return markers;
}

/**
 * Превращает текст с маркерами перечисления в маркированный список.
 * Перечисление ограничено последним предложением с маркером.
 */
function structureEnumerations(text) {
    text = removeInterjections(text);

    var markers = findEnumerationMarkers(text);
    if (markers.length < 2) return text;

    var lastMarker = markers[markers.length - 1];
    var enumerationEnd = findSentenceEnd(text, lastMarker.markerEnd);

    var usedMarkers = [];
    for (var i = 0; i < markers.length; i++) {
        if (markers[i].markerStart < enumerationEnd) {
            usedMarkers.push(markers[i]);
        }
    }
    if (usedMarkers.length < 2) return text;

    var before = text.substring(0, usedMarkers[0].markerStart);
    before = before.replace(/[\s,.!?;:]+$/, "");
    before = before.replace(/^\s+/, "");

    var items = [];
    for (var j = 0; j < usedMarkers.length; j++) {
        var start = usedMarkers[j].markerEnd;
        var end;
        if (j + 1 < usedMarkers.length) {
            end = usedMarkers[j + 1].markerStart;
        } else {
            end = enumerationEnd;
        }
var content = text.substring(start, end);
content = content.replace(/^[\s,.!?;:]+/, "");
content = content.replace(/[\s,.!?;:]+$/, "");
content = trim(content);
// Убираем висящие союзы в конце: «...отображение и» → «...отображение».
content = content.replace(/\s+(и|а|но|или|либо|да|же)$/i, "");
content = trim(content);
if (content.length > 0) {
    items.push(capitalizeFirst(content));
}
    }

    if (items.length < 2) return text;

    var after = text.substring(enumerationEnd);
    after = after.replace(/^[\s,.!?;:]+/, "");
    after = after.replace(/\s+$/, "");

    var result = [];
    if (before.length > 0) {
        result.push(capitalizeFirst(before));
        result.push("");
    }
    for (var k = 0; k < items.length; k++) {
        result.push("- " + items[k]);
    }
    if (after.length > 0) {
        result.push("");
        result.push(after);
    }

    return result.join("\n").replace(/\n{3,}/g, "\n\n");
}

var MID_SENTENCE_LOWERCASE = [
    "где", "когда", "который", "которая", "которое", "которые",
    "если", "чтобы", "что", "как", "чем", "зачем", "почему"
];

function lowercaseMidSentence(text) {
    for (var i = 0; i < MID_SENTENCE_LOWERCASE.length; i++) {
        var word = MID_SENTENCE_LOWERCASE[i];
        var upperWord = word.charAt(0).toUpperCase() + word.substring(1);
        var re = new RegExp(
            "([а-яё]\\s+)" + escapeRegex(upperWord) + "(\\s|$|[,.!?;:])",
            "g"
        );
        text = text.replace(re, function(m, before, after) {
            return before + word + after;
        });
    }
    return text;
}

/**
 * Проверяет, является ли предложение задачей.
 *
 * Два пути:
 *  1. Сработал containsMarker по TASK_MARKERS — стандартный путь.
 *  2. Маркеров нет, но первое слово — глагол-инфинитив или императив
 *     из IMPERATIVE_VERBS. Fallback для неохваченных случаев.
 *
 * Дальше — общие фильтры: не прошлое, не размышление, не длинное.
 */
function isTaskSentence(sentence) {
    var hasTask = containsMarker(sentence, TASK_MARKERS);

    // Fallback: первое слово — глагол.
    if (!hasTask) {
        var firstWord = (sentence.match(/\S+/) || [""])[0];
        if (!isVerbForm(firstWord)) return false;
    }

    var hasModal = containsMarker(sentence, MODAL_MARKERS);
    var hasPast = containsMarker(sentence, PAST_TENSE_MARKERS);
    if (hasModal && hasPast) return false;

    if (containsMarker(sentence, REFLECTION_MARKERS)) return false;

    var wordCount = (sentence.match(/\S+/g) || []).length;
    if (wordCount > 10) return false;

    return true;
}

/**
 * Проверяет, отмечена ли задача как выполненная.
 */
function isDoneSentence(sentence) {
    return containsMarker(sentence, DONE_MARKERS);
}

/**
 * Убирает вводные маркеры темы и модальные маркеры задачи.
 * Вводные темы — только в начале.
 * Модальные задачи — где угодно (в начале и в середине).
 */
function stripTaskMarker(sentence) {
    var cleaned = sentence;

    // 1. Убираем вводные маркеры темы в начале.
    for (var t = 0; t < STRIPPABLE_TOPIC_MARKERS.length; t++) {
        var topicMarker = STRIPPABLE_TOPIC_MARKERS[t];
        var topicRe = new RegExp(
            "^\\s*" + escapeRegex(topicMarker) + "[,:]?\\s*",
            "i"
        );
        if (topicRe.test(cleaned)) {
            cleaned = cleaned.replace(topicRe, "");
            break;
        }
    }

    // 2. Убираем модальные маркеры задачи везде.
    for (var i = 0; i < REMOVABLE_TASK_MARKERS.length; i++) {
        var marker = REMOVABLE_TASK_MARKERS[i];
        var re = new RegExp(
            "(^|\\s)" + escapeRegex(marker) + "(\\s+)",
            "gi"
        );
        cleaned = cleaned.replace(re, function(match, before, after) {
            if (before === "") return "";
            return before;
        });
    }

    // 3. Убираем двойные пробелы.
    cleaned = cleaned.replace(/[ \t]{2,}/g, " ");

    return cleaned;
}

/**
 * Проверяет, является ли слово глаголом-инфинитивом или императивом.
 *
 * Эвристика:
 *  - инфинитив: -ть, -ти, -чь (в т.ч. -ться, -ться);
 *  - императив: точное совпадение с IMPERATIVE_VERBS.
 *
 * Намеренно НЕ проверяем императив по окончанию «-и»: это ловит
 * сущ. («молоко», «окно», «хлеб») и даёт ложные срабатывания.
 * Лучше пропустить редкий глагол, чем сломать сущ. в середине задачи.
 */
function isVerbForm(word) {
    if (!word || word.length < 3) return false;
    var w = word.toLowerCase();

    // Инфинитив. «-ться» покрывается «-ть$», отдельная проверка не нужна.
    if (/[а-яё]ть$/.test(w)) return true;
    if (/[а-яё]ти$/.test(w)) return true;
    if (/[а-яё]чь$/.test(w)) return true;

    // Императив — только точное совпадение со списком.
    for (var i = 0; i < IMPERATIVE_VERBS.length; i++) {
        if (w === IMPERATIVE_VERBS[i]) return true;
    }

    return false;
}

/**
 * Разделяет сложную задачу на несколько по союзам.
 * Возвращает массив строк — каждая это отдельная задача.
 *
 * Разделяем, если союз «и», «а также», «плюс», «затем», «потом»
 * соединяет две части, каждая из которых содержит глагол.
 */
function splitComplexTask(task) {
    if (!task || task.length === 0) return [task];

    // Паттерны-разделители: союз + пробел.
    // Ищем « и », « а также », « плюс », « затем », « потом ».
    // Разделяем только если вторая часть начинается с глагола.

    var separators = [
        { regex: /\s+а\s+также\s+/i, name: "а также" },
        { regex: /\s+затем\s+/i, name: "затем" },
        { regex: /\s+потом\s+/i, name: "потом" },
        { regex: /\s+плюс\s+/i, name: "плюс" },
        { regex: /\s+и\s+/i, name: "и" }
    ];

    // Пробуем каждый разделитель — берём первый, который сработает.
    for (var i = 0; i < separators.length; i++) {
        var sep = separators[i];
        var match = sep.regex.exec(task);
        if (!match) continue;

        var leftPart = task.substring(0, match.index).replace(/\s+$/, "");
        var rightPart = task.substring(match.index + match[0].length);

        if (leftPart.length < 3 || rightPart.length < 3) continue;

        // Проверяем, что вторая часть начинается с глагола.
        var rightWords = rightPart.split(/\s+/);
        var firstWord = rightWords.length > 0 ? rightWords[0] : "";
        if (!isVerbForm(firstWord)) continue;

        // Проверяем, что в первой части тоже есть глагол.
        // Ищем глагол в любом слове первой части.
        var leftWords = leftPart.split(/\s+/);
        var hasVerbInLeft = false;
        for (var j = 0; j < leftWords.length; j++) {
            if (isVerbForm(leftWords[j])) {
                hasVerbInLeft = true;
                break;
            }
        }
        if (!hasVerbInLeft) continue;

        // Разделяем рекурсивно (может быть больше двух частей).
        var leftResults = splitComplexTask(leftPart);
        var rightResults = splitComplexTask(rightPart);
        return leftResults.concat(rightResults);
    }

    return [task];
}

/**
 * Превращает предложения-задачи в чек-лист.
 * Все задачи собираются в ОДИН блок «## Задачи» в конце заметки.
 *  - незавершённые → «- [ ] …»
 *  - завершённые → «- [x] …»
 *  - «надо было…» → не задача, остаётся как текст.
 */
function structureTasks(text) {
    var lines = text.split("\n");
    var textBuffer = [];
    var allTasks = [];

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        var trimmed = trim(line);

        if (trimmed.length === 0) {
            textBuffer.push(line);
            continue;
        }
        if (/^(#|[-*+]|\d+\.|>|```|\|)/.test(trimmed)) {
            textBuffer.push(line);
            continue;
        }

        var sentences = splitSentences(trimmed);
        var nonTaskSentences = [];

        for (var s = 0; s < sentences.length; s++) {
            var sentence = trim(sentences[s]);
            if (sentence.length === 0) continue;

if (isTaskSentence(sentence)) {
    var isDone = isDoneSentence(sentence);
    var cleaned = isDone ? sentence : stripTaskMarker(sentence);
    cleaned = cleaned.replace(/[.!?…]+$/, "");
    cleaned = capitalizeFirst(trim(cleaned));

    // Разделяем сложные задачи на несколько.
    var subtasks = splitComplexTask(cleaned);
    var checkbox = isDone ? "- [x] " : "- [ ] ";
    for (var t = 0; t < subtasks.length; t++) {
        var sub = capitalizeFirst(trim(subtasks[t]));
        if (sub.length > 0) {
            allTasks.push(checkbox + sub);
        }
    }
} else {
                nonTaskSentences.push(sentence);
            }
        }

        if (nonTaskSentences.length > 0) {
            textBuffer.push(nonTaskSentences.join(" "));
        }
    }

    var output = textBuffer.join("\n").replace(/\n{3,}/g, "\n\n");
    output = output.replace(/^\s+|\s+$/g, "");

    if (allTasks.length > 0) {
        if (output.length > 0) output += "\n\n";
        output += "## Задачи\n";
        for (var t = 0; t < allTasks.length; t++) {
            output += allTasks[t] + "\n";
        }
    }

    return output.replace(/\n{3,}/g, "\n\n").replace(/\s+$/, "");
}

/**
 * Вставляет разрыв параграфа перед маркерами темы.
 * Работает и когда перед маркером есть точка, и когда нет.
 */
function structureTopicBreaks(text) {
    var result = text;
    for (var i = 0; i < TOPIC_MARKERS.length; i++) {
        var marker = TOPIC_MARKERS[i];
        var re = new RegExp(
            "(^|[\\.!?…]\\s+|\\n\\s*\\n\\s*)(" + escapeRegex(marker) + ")(\\s|$|[,.!?;:])",
            "gi"
        );
        result = result.replace(re, function(match, before, m, after) {
            if (/\n\s*\n\s*$/.test(before)) return before + m + after;
            if (before === "") return m + after;
            return before.replace(/\s+$/, "") + "\n\n" + m + after;
        });
    }
    return result.replace(/\n{3,}/g, "\n\n");
}


// =====================================================================
// ЧАСТЬ 5. КОНТЕКСТ
// =====================================================================

function suggestTags(text) {
    var words = text.toLowerCase().match(/[а-яёa-z]{4,}/g) || [];
    var stop = {
        "этот": 1, "эта": 1, "это": 1, "эти": 1,
        "который": 1, "которая": 1, "которое": 1, "которые": 1,
        "быть": 1, "был": 1, "была": 1, "было": 1, "были": 1,
        "есть": 1, "надо": 1, "нужно": 1,
        "если": 1, "чтобы": 1, "когда": 1, "потому": 1,
        "также": 1, "тоже": 1, "себя": 1,
        "очень": 1, "просто": 1, "более": 1, "менее": 1,
        "можно": 1, "нельзя": 1, "будет": 1, "будут": 1
    };
    var freq = {};
    for (var i = 0; i < words.length; i++) {
        var w = words[i];
        if (stop[w]) continue;
        freq[w] = (freq[w] || 0) + 1;
    }
    var sorted = [];
    for (var k in freq) {
        if (!freq.hasOwnProperty(k)) continue;
        if (freq[k] >= 2) sorted.push({ word: k, count: freq[k] });
    }
    sorted.sort(function(a, b) { return b.count - a.count; });
    var result = [];
    for (var j = 0; j < Math.min(3, sorted.length); j++) {
        result.push(sorted[j].word);
    }
    return result;
}

function suggestWikiLinks(text) {
    try {
        var all = oniks.notes.getAll();
        if (!all || all.length === 0) return [];
        var lower = text.toLowerCase();
        var result = [];
        for (var i = 0; i < all.length; i++) {
            var note = all[i];
            if (!note.title || note.title.length < 4) continue;
            var title = note.title;
            if (lower.indexOf(title.toLowerCase()) >= 0) {
                result.push(title);
            }
            if (result.length >= 3) break;
        }
        return result;
    } catch (e) {
        oniks.log.warn("suggestWikiLinks error: " + e.message);
        return [];
    }
}


// =====================================================================
// ЧАСТЬ 6. PIPELINE И PREVIEW
// =====================================================================

function runPipeline(text, cfg) {
    var result = text;

    if (cfg.cleanFillers) {
        result = removeFillers(result, cfg);
    }
    if (cfg.cleanDuplicates) {
        result = removeDuplicateWords(result);
    }
    result = fixSpaces(result);

    if (cfg.structureEnumerations) {
        result = structureEnumerations(result);
    }
    if (cfg.structureTopicBreaks) {
        result = structureTopicBreaks(result);
    }
    if (cfg.structureTasks) {
        result = structureTasks(result);
    }

    if (cfg.fixCapitalization) {
        result = fixCapitalization(result);
    }
    if (cfg.fixPunctuation) {
        result = fixPunctuation(result);
    }

    result = result.replace(/\n{3,}/g, "\n\n");
    result = result.replace(/^\s+|\s+$/g, "");
    return result;
}

function runCleanOnly(text, cfg) {
    var cleanCfg = {};
    for (var k in cfg) if (cfg.hasOwnProperty(k)) cleanCfg[k] = cfg[k];
    cleanCfg.structureEnumerations = false;
    cleanCfg.structureTasks = false;
    cleanCfg.structureTopicBreaks = false;
    return runPipeline(text, cleanCfg);
}

function runStructureOnly(text, cfg) {
    var structCfg = {};
    for (var k in cfg) if (cfg.hasOwnProperty(k)) structCfg[k] = cfg[k];
    structCfg.cleanFillers = false;
    structCfg.cleanDuplicates = false;
    structCfg.fixCapitalization = false;
    structCfg.fixPunctuation = false;
    var result = runPipeline(text, structCfg);
    result = removeInterjections(result);
    result = result.replace(/\s{2,}/g, " ");
    return result;
}

function buildDiffSummary(before, after) {
    var beforeWords = (before.match(/\S+/g) || []).length;
    var afterWords = (after.match(/\S+/g) || []).length;
    var removed = beforeWords - afterWords;

    var summary = "Слов: " + beforeWords + " → " + afterWords;
    if (removed > 0) {
        summary += " (−" + removed + ")";
    }
    return summary;
}

function confirmImprovement(before, after) {
    var summary = buildDiffSummary(before, after);
    var preview = after;
    if (preview.length > 1500) {
        preview = preview.substring(0, 1500) + "\n\n…(усечено)";
    }
    var message = summary + "\n\n─── Предпросмотр ───\n\n" + preview;
    return oniks.dialog.confirm(message, "Улучшение текста");
}


// =====================================================================
// ЧАСТЬ 7. КОМАНДЫ
// =====================================================================

oniks.commands.register({
    id: "improve-note",
    title: "Улучшить текст заметки",
    handler: function() {
        var cfg = loadConfig();
        var text = oniks.editor.getFullText();
        if (!text || text.length < 3) {
            oniks.dialog.alert("Заметка пуста.");
            return;
        }

        var improved = runPipeline(text, cfg);

        if (improved === text) {
            oniks.dialog.alert("Нечего улучшать.");
            return;
        }

        if (confirmImprovement(text, improved)) {
            oniks.editor.setFullText(improved);
            oniks.log.info("Note improved");
        }
    }
});

oniks.commands.register({
    id: "clean-only",
    title: "Только очистка (без структуры)",
    handler: function() {
        var cfg = loadConfig();
        var text = oniks.editor.getFullText();
        if (!text) return;

        var improved = runCleanOnly(text, cfg);
        if (improved === text) {
            oniks.dialog.alert("Нечего улучшать.");
            return;
        }

        if (confirmImprovement(text, improved)) {
            oniks.editor.setFullText(improved);
            oniks.log.info("Cleaned only");
        }
    }
});

oniks.commands.register({
    id: "structure-only",
    title: "Только структура (без очистки)",
    handler: function() {
        var cfg = loadConfig();
        var text = oniks.editor.getFullText();
        if (!text) return;

        var improved = runStructureOnly(text, cfg);
        if (improved === text) {
            oniks.dialog.alert("Нечего структурировать.");
            return;
        }

        if (confirmImprovement(text, improved)) {
            oniks.editor.setFullText(improved);
            oniks.log.info("Structured only");
        }
    }
});

oniks.commands.register({
    id: "improve-selection",
    title: "Улучшить выделенный текст",
    handler: function() {
        var cfg = loadConfig();
        var text = oniks.editor.getSelection();
        if (!text || text.length < 3) {
            oniks.dialog.alert("Выделите текст для улучшения.");
            return;
        }

        var improved = runPipeline(text, cfg);

        if (improved === text) {
            oniks.dialog.alert("Нечего улучшать.");
            return;
        }

        if (oniks.dialog.confirm(improved, "Улучшить выделение")) {
            oniks.editor.insertText(improved);
        }
    }
});

oniks.commands.register({
    id: "suggest-tags",
    title: "Предложить теги",
    handler: function() {
        var text = oniks.editor.getFullText();
        if (!text) return;

        var tags = suggestTags(text);
        if (tags.length === 0) {
            oniks.dialog.alert("Не удалось выделить ключевые слова.");
            return;
        }

        var message = "Предлагаемые теги:\n\n" + tags.join(", ");
        if (oniks.dialog.confirm(message, "Добавить теги?")) {
            var suffix = "\n\n# " + tags.join(" #");
            oniks.editor.insertText(suffix);
            oniks.log.info("Tags suggested: " + tags.join(", "));
        }
    }
});

oniks.commands.register({
    id: "suggest-links",
    title: "Предложить wiki-ссылки",
    handler: function() {
        var text = oniks.editor.getFullText();
        if (!text) return;

        var links = suggestWikiLinks(text);
        if (links.length === 0) {
            oniks.dialog.alert("Похожих заметок не найдено.");
            return;
        }

        var arr = [];
        for (var i = 0; i < links.length; i++) {
            arr.push("[[ " + links[i] + " ]]");
        }
        var message = "Найдены заметки с похожими заголовками:\n\n" + arr.join("\n");
        oniks.dialog.alert(message, "Возможные ссылки");
    }
});

oniks.commands.register({
    id: "settings",
    title: "Настройки очистки",
    handler: function() {
        var cfg = loadConfig();
        var current = cfg.aggressiveness;
        var next;
        if (current === "light") next = "normal";
        else if (current === "normal") next = "aggressive";
        else next = "light";

        if (oniks.dialog.confirm(
            "Текущий уровень: " + current + "\nПереключить на: " + next + "?",
            "Настройки очистки"
        )) {
            cfg.aggressiveness = next;
            saveConfig(cfg);
            oniks.log.info("Aggressiveness set to: " + next);
        }
    }
});

oniks.commands.register({
    id: "reset-config",
    title: "Сбросить настройки плагина",
    handler: function() {
        if (oniks.dialog.confirm("Сбросить все настройки?", "Сброс")) {
            saveConfig(DEFAULT_CONFIG);
            oniks.log.info("Config reset to defaults");
        }
    }
});


// =====================================================================
// INIT
// =====================================================================

oniks.log.info("Smart Improver loaded, commands: 8");